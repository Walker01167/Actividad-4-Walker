﻿using System;
using System.Collections.Generic;

namespace RestAPIPrueba.Models;

public partial class Categoria
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
}
